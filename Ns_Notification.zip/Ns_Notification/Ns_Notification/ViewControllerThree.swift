//
//  ViewControllerThree.swift
//  Ns_Notification
//
//  Created by Pulipati Venkata Sai on 17/10/22.
//

import UIKit

class ViewControllerThree: UIViewController {

    @IBOutlet weak var displayLable: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        NotificationCenter.default.addObserver(self, selector: #selector(notficationObserver), name: Notifications.NotificationSample, object: nil)
    }
    
    @objc func notficationObserver(_ notification:Notification){
        print("Notification received in ViewContollerThree!!")
        print(notification.userInfo)
        if let userInfoPayload = notification.userInfo{
            displayLable.text = userInfoPayload["Learning"] as? String
        }
    }
    

   
}
