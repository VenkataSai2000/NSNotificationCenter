//
//  ViewController2.swift
//  Ns_Notification
//
//  Created by Pulipati Venkata Sai on 17/10/22.
//

import UIKit

class ViewController2: UIViewController {


    @IBOutlet weak var displayLable: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(notficationObserver), name: Notifications.NotificationSample, object: nil)

        // Do any additional setup after loading the view.
    }
    @objc func notficationObserver(_ notification:Notification){
        print("Notification received in ViewContoller2!!")
        print(notification.userInfo)
        if let userInfoPayload = notification.userInfo{
            displayLable.text = userInfoPayload["Learning"] as? String
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    

  

}
