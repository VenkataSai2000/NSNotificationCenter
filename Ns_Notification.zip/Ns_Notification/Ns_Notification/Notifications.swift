//
//  Notifications.swift
//  Ns_Notification
//
//  Created by Pulipati Venkata Sai on 17/10/22.
//

import Foundation

class Notifications{
    static let NotificationSample = NSNotification.Name(rawValue: "DemoSample")
}
