//
//  ViewController.swift
//  Ns_Notification
//
//  Created by Pulipati Venkata Sai on 17/10/22.
//

import UIKit

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
           }


    @IBAction func publishNotification(_ sender: Any) {
        NotificationCenter.default.post(name:Notifications.NotificationSample, object: nil, userInfo: ["Learning":"You Tube"])

    }
}

