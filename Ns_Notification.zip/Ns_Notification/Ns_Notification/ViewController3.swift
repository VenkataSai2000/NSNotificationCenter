//
//  ViewController3.swift
//  Ns_Notification
//
//  Created by Pulipati Venkata Sai on 17/10/22.
//

import UIKit

class ViewController3: UIViewController {

    
    @IBOutlet weak var nameLable: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        NotificationCenter.default.addObserver(self, selector: #selector(notficationObserver), name: Notifications.NotificationSample, object: nil)
    }
    
    @objc func notficationObserver(_ notification:Notification){
        print("Notification received in ViewContoller3!!")
        print(notification.userInfo)
        if let userInfoPayload = notification.userInfo{
            self.nameLable.text = userInfoPayload["Learning"] as? String
        }
    }
    

    
}
